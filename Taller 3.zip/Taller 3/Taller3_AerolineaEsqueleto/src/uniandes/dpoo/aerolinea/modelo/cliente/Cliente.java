package uniandes.dpoo.aerolinea.modelo.cliente;

import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public abstract class Cliente {
	
	private List<Tiquete> tiquetesSinUsar;
	private List<Tiquete> tiquetesUsados;
	
	public Cliente() {
		tiquetesSinUsar = new ArrayList<Tiquete>();
		tiquetesUsados = new ArrayList<Tiquete>();
	}
	
	public abstract String getTipoCliente();
	public abstract String getIdentificador();
	
	public void agregarTiquete(Tiquete tiquete) {
		tiquetesSinUsar.addLast(tiquete);
	}
	
	public int calcularValorTiquetes() {
		int total = 0;
		for (Tiquete tiquete : tiquetesSinUsar) {
			total += tiquete.getTarifa();
		}
		for (Tiquete tiquete : tiquetesUsados) {
			total += tiquete.getTarifa();
		}
		
		return total;
	}
}
