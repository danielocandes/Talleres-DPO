package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.cliente.ClienteCorporativo;

public class CalculadoraTarifasTemporadaBaja extends CalculadoraTarifas{

	protected static final int COSTO_POR_KM_NATURAL = 600;
	protected static final int COSTO_POR_KM_CORPORATIVO = 900;
	protected static final double DESCUENTO_PEQ = 0.02;
	protected static final double DESCUENTO_MEDIANAS = 0.1;
	protected static final double DESCUENTO_GRANDES = 0.2;
	
	
	protected int calcularCostoBase(Vuelo vuelo, Cliente cliente) {
		Aeropuerto origen = vuelo.getRuta().getOrigen();
		Aeropuerto destino = vuelo.getRuta().getDestino();
		int distancia = Aeropuerto.calcularDistancia(origen, destino);
		
		if (cliente.getTipoCliente().equals("Natural")) {
			return COSTO_POR_KM_NATURAL * distancia;
		} else {
			return COSTO_POR_KM_CORPORATIVO * distancia;
		}
	}

	protected double calcularPorcentajeDescuento(Cliente cliente) {
		if (cliente.getTipoCliente().equals("Natural")) {
			return 0.0;
		} else {
			ClienteCorporativo clienteCorp = (ClienteCorporativo) cliente;
			int tamano = clienteCorp.getTamanoEmpresa();
			if (tamano == 1) {
				return DESCUENTO_GRANDES;
			} else if (tamano == 2) {
				return DESCUENTO_MEDIANAS;
			} else {
				return DESCUENTO_PEQ;
			}
		}
	}

}
