package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public class CalculadoraTarifasTemporadaAlta extends CalculadoraTarifas {

	protected static final int COSTO_POR_KM = 1000;
	@Override
	protected int calcularCostoBase(Vuelo vuelo, Cliente cliente) {
		Aeropuerto origen = vuelo.getRuta().getOrigen();
		Aeropuerto destino = vuelo.getRuta().getDestino();
		int distancia = Aeropuerto.calcularDistancia(origen, destino);
		
		return COSTO_POR_KM * distancia;
	}

	protected double calcularPorcentajeDescuento(Cliente cliente) {
		return 0; // no parece haber descuento para temporada alta
	}

}
